from setuptools import setup

setup(name='PyGauss_Binomial',
      version='1.0.0',
      description= 'Gaussian distributions and Binomial Distribution',
      packages=['PyGauss_Binomial'],
      author = "Mohammad Omar Adde",
      author_email = "mohaomar495@gmail.com",
      zip_safe=False)
